import requests
from pathlib import Path
from .config import PROMPTS_DIR

DEFAULT_OLLAMA_URL = "http://localhost:11434/api/generate"

def _load_prompt_template() -> str:
    p = PROMPTS_DIR / "mom_v2_prompt.txt"
    if p.exists():
        return p.read_text(encoding="utf-8")
    return (
        "You are an expert meeting assistant. Given transcript, produce MoM in SAME LANGUAGE as transcript. "
        "Return JSON with keys: summary, decisions, action_items, risks, next_steps."
    )

def generate_mom_v2_ollama(transcript: str, lang: str, model: str = "qwen2.5:3b-instruct", ollama_url: str = DEFAULT_OLLAMA_URL) -> dict:
    prompt_tpl = _load_prompt_template()
    prompt = prompt_tpl.replace("{{LANG}}", lang or "auto").replace("{{TRANSCRIPT}}", transcript)

    payload = {
        "model": model,
        "prompt": prompt,
        "stream": False,
        "options": {
            "temperature": 0.2,
            "num_ctx": 4096
        }
    }
    r = requests.post(ollama_url, json=payload, timeout=120)
    r.raise_for_status()
    data = r.json()
    text = data.get("response", "").strip()

    # Best-effort: if model returns JSON, parse; else wrap into MoM.
    mom = {"engine": "v2-ollama", "language": lang, "raw": text}
    try:
        import json
        parsed = json.loads(text)
        if isinstance(parsed, dict):
            mom.update(parsed)
    except Exception:
        mom["summary"] = text[:1200]
    return mom
