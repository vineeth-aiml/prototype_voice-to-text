def to_txt(meeting: dict) -> str:
    t = meeting.get("transcript", "")
    mom = meeting.get("mom") or {}
    lines = []
    lines.append("TRANSCRIPT")
    lines.append(t)
    lines.append("")
    lines.append("MoM")
    for k in ["summary","decisions","action_items","risks","next_steps"]:
        if k in mom:
            lines.append(f"{k.upper()}:")
            v = mom.get(k)
            if isinstance(v, list):
                for i, it in enumerate(v, 1):
                    lines.append(f"  {i}. {it}")
            else:
                lines.append(f"  {v}")
            lines.append("")
    return "\n".join(lines).strip() + "\n"

def to_md(meeting: dict) -> str:
    t = meeting.get("transcript","")
    mom = meeting.get("mom") or {}
    md = []
    md.append("# Meeting Notes")
    md.append("")
    md.append("## Transcript")
    md.append("")
    md.append(t or "")
    md.append("")
    md.append("## MoM")
    md.append("")
    for k in ["summary","decisions","action_items","risks","next_steps"]:
        if k in mom:
            md.append(f"### {k.replace('_',' ').title()}")
            v = mom.get(k)
            if isinstance(v, list):
                for it in v:
                    md.append(f"- {it}")
            else:
                md.append(str(v))
            md.append("")
    return "\n".join(md).strip() + "\n"
