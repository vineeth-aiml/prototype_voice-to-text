from pathlib import Path
import yaml

ROOT = Path(__file__).resolve().parents[2]
FLAGS_PATH = ROOT.parent / "ops" / "feature_flags.yaml"
PROMPTS_DIR = ROOT.parent / "prompts"

def load_flags() -> dict:
    if FLAGS_PATH.exists():
        return yaml.safe_load(FLAGS_PATH.read_text(encoding="utf-8")) or {}
    return {}

def get_flag(name: str, default=None):
    flags = load_flags()
    return flags.get(name, default)
