from .config import get_flag
from .mom_engine_v1 import generate_mom_v1
from .mom_engine_v2_ollama import generate_mom_v2_ollama

def generate_mom(transcript: str, lang: str):
    engine = (get_flag("MOM_ENGINE", "v2") or "v2").lower().strip()

    if engine == "v1":
        return generate_mom_v1(transcript, lang=lang)

    # v2 default: Ollama if available, else fallback to v1
    try:
        model = get_flag("OLLAMA_MODEL", "qwen2.5:3b-instruct")
        return generate_mom_v2_ollama(transcript, lang=lang, model=model)
    except Exception:
        return generate_mom_v1(transcript, lang=lang)
