import time
from ..stt_engine import STTEngine

# This is a placeholder demo. In real CI, run on a short wav and assert p95 latency.
if __name__ == "__main__":
    engine = STTEngine()
    wav = "sample.wav"  # put a tiny wav here if you want
    t0 = time.time()
    try:
        engine.transcribe_file(wav, language="en")
    except Exception as e:
        print("Provide sample.wav to run:", e)
    print("Elapsed:", time.time() - t0)
