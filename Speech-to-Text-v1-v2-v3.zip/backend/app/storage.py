import json
from pathlib import Path
from datetime import datetime

DATA_DIR = Path("data/meetings")
DATA_DIR.mkdir(parents=True, exist_ok=True)

def save_meeting(meeting: dict) -> str:
    meeting_id = meeting.get("id") or datetime.utcnow().strftime("%Y%m%d%H%M%S")
    path = DATA_DIR / f"{meeting_id}.json"
    meeting["id"] = meeting_id
    path.write_text(json.dumps(meeting, ensure_ascii=False, indent=2), encoding="utf-8")
    return meeting_id

def list_meetings():
    items = []
    for p in sorted(DATA_DIR.glob("*.json"), reverse=True):
        try:
            items.append(json.loads(p.read_text(encoding="utf-8")))
        except Exception:
            continue
    return items

def read_meeting(meeting_id: str):
    path = DATA_DIR / f"{meeting_id}.json"
    return json.loads(path.read_text(encoding="utf-8"))

def update_meeting(meeting_id: str, patch: dict):
    m = read_meeting(meeting_id)
    m.update(patch)
    save_meeting(m)
    return m
