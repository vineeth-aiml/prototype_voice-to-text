import re

def generate_mom_v1(transcript: str, lang: str = "en") -> dict:
    # Simple rule-based MoM (works offline, any language but best in English)
    text = transcript.strip()

    action_patterns = [
        r"\bwe will\b", r"\bi will\b", r"\bplease\b", r"\bneed to\b", r"\bshall\b",
        # Some common Indian-language cues (very rough, optional):
        r"చేయాలి", r"చేద్దాం", r"చెయ్యాలి", r"చేస్తాను",  # Telugu
        r"करेंगे", r"करना है", r"कर दूँगा",                 # Hindi
        r"செய்ய", r"வேண்டும்",                               # Tamil
        r"ಮಾಡಬೇಕು", r"ಮಾಡೋಣ"                                # Kannada
    ]
    actions = []
    for sent in re.split(r"[.\n!?]+", text):
        s = sent.strip()
        if not s:
            continue
        s_low = s.lower()
        if any(re.search(p, s_low) for p in action_patterns) and len(s) > 8:
            actions.append(s)

    decisions = []
    for sent in re.split(r"[.\n!?]+", text):
        s = sent.strip()
        if re.search(r"\b(decided|final|approved|confirmed)\b", s.lower()):
            decisions.append(s)

    return {
        "engine": "v1-rule-based",
        "language": lang,
        "summary": "MoM generated with V1 (rule-based). For best quality, enable V2 (Ollama LLM).",
        "decisions": decisions[:12],
        "action_items": actions[:15],
        "next_steps": actions[:8]
    }
