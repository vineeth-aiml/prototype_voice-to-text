from pathlib import Path
from faster_whisper import WhisperModel
from .config import get_flag

class STTEngine:
    def __init__(self):
        model_name = get_flag("WHISPER_MODEL", "small")
        models_dir = Path("models/whisper")
        local_path = models_dir / model_name
        # If local path exists, use it (offline). Otherwise, faster-whisper will try to fetch (online).
        model_ref = str(local_path) if local_path.exists() else model_name

        self.model = WhisperModel(
            model_ref,
            device="cpu",
            compute_type="int8"  # best for CPU
        )

    def transcribe_file(self, wav_path: str, language: str = "auto"):
        # language: "auto" or ISO 639-1 like "en", "hi", "te"
        lang = None if (language in (None, "", "auto")) else language
        segments, info = self.model.transcribe(
            wav_path,
            vad_filter=True,
            language=lang
        )
        text_parts = []
        for seg in segments:
            if seg.text:
                text_parts.append(seg.text.strip())
        text = " ".join([t for t in text_parts if t])
        meta = {
            "language": getattr(info, "language", None),
            "duration": getattr(info, "duration", None),
            "vad": True
        }
        return text.strip(), meta
