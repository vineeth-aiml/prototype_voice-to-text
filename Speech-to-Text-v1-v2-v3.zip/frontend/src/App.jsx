import React, { useEffect, useRef, useState } from "react";
import MeetingList from "./components/MeetingList.jsx";
import MoMView from "./components/MoMView.jsx";

const API = "http://localhost:8000";

function downloadText(filename, text) {
  const blob = new Blob([text], { type: "text/plain;charset=utf-8" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  a.click();
  URL.revokeObjectURL(a.href);
}

export default function App() {
  const [status, setStatus] = useState("idle");
  const [roomId, setRoomId] = useState("default");
  const [language, setLanguage] = useState("auto");
  const [transcript, setTranscript] = useState("");
  const [meta, setMeta] = useState(null);
  const [meetingId, setMeetingId] = useState(String(Date.now()));
  const [meetings, setMeetings] = useState([]);
  const [selectedMeeting, setSelectedMeeting] = useState(null);
  const [mom, setMom] = useState(null);

  const wsRef = useRef(null);
  const audioCtxRef = useRef(null);
  const processorRef = useRef(null);
  const streamRef = useRef(null);

  const refreshMeetings = async () => {
    const res = await fetch(`${API}/api/meetings`);
    const data = await res.json();
    setMeetings(data);
  };

  useEffect(() => {
    refreshMeetings();
  }, []);

  const start = async () => {
    setStatus("starting");
    setTranscript("");
    setMom(null);
    setMeta(null);
    const newMeetingId = String(Date.now());
    setMeetingId(newMeetingId);

    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    streamRef.current = stream;

    const AudioContext = window.AudioContext || window.webkitAudioContext;
    // Ask for 16k; some browsers may still use device rate. This is good enough for V1.
    const audioCtx = new AudioContext({ sampleRate: 16000 });
    audioCtxRef.current = audioCtx;

    const source = audioCtx.createMediaStreamSource(stream);
    const processor = audioCtx.createScriptProcessor(4096, 1, 1);
    processorRef.current = processor;

    const ws = new WebSocket(`ws://localhost:8000/ws/stt?room_id=${encodeURIComponent(roomId)}&lang=${encodeURIComponent(language)}`);
    wsRef.current = ws;

    ws.onopen = () => setStatus("live");
    ws.onmessage = (evt) => {
      const msg = JSON.parse(evt.data);
      if (msg.type === "partial") {
        setTranscript(msg.text);
        setMeta(msg.meta || null);
      }
    };
    ws.onerror = () => setStatus("error");
    ws.onclose = () => setStatus("stopped");

    processor.onaudioprocess = (e) => {
      if (!wsRef.current || wsRef.current.readyState !== 1) return;
      const input = e.inputBuffer.getChannelData(0);
      const buf = new ArrayBuffer(input.length * 2);
      const view = new DataView(buf);
      for (let i = 0; i < input.length; i++) {
        let s = Math.max(-1, Math.min(1, input[i]));
        view.setInt16(i * 2, s < 0 ? s * 0x8000 : s * 0x7fff, true);
      }
      wsRef.current.send(buf);
    };

    source.connect(processor);
    processor.connect(audioCtx.destination);
  };

  const stop = async () => {
    setStatus("stopping");
    try {
      if (wsRef.current) wsRef.current.close();
      if (processorRef.current) processorRef.current.disconnect();
      if (audioCtxRef.current) await audioCtxRef.current.close();
      if (streamRef.current) streamRef.current.getTracks().forEach(t => t.stop());
    } catch {}
    setStatus("stopped");
  };

  const saveMeeting = async () => {
    const payload = { id: meetingId, room_id: roomId, language: meta?.language || language, transcript };
    const res = await fetch(`${API}/api/meetings/save`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    const data = await res.json();
    await refreshMeetings();
    alert("Saved meeting: " + data.meeting_id);
  };

  const generateMoM = async () => {
    const lang = meta?.language || language || "auto";
    const res = await fetch(`${API}/api/mom`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ meeting_id: meetingId, transcript, language: lang })
    });
    const data = await res.json();
    setMom(data.mom);
    await refreshMeetings();
  };

  const openMeeting = async (id) => {
    const res = await fetch(`${API}/api/meetings/${id}`);
    const data = await res.json();
    setSelectedMeeting(data);
    setTranscript(data.transcript || "");
    setMom(data.mom || null);
    setMeetingId(data.id);
    setRoomId(data.room_id || "default");
    setLanguage(data.language || "auto");
  };

  const exportTxt = async () => {
    const res = await fetch(`${API}/api/meetings/${meetingId}/export.txt`);
    const text = await res.text();
    downloadText(`${meetingId}.txt`, text);
  };

  const exportMd = async () => {
    const res = await fetch(`${API}/api/meetings/${meetingId}/export.md`);
    const text = await res.text();
    downloadText(`${meetingId}.md`, text);
  };

  return (
    <div style={{ padding: 20, fontFamily: "Arial, sans-serif", maxWidth: 1100, margin: "0 auto" }}>
      <h2 style={{ marginTop: 0 }}>Offline Speech-to-Text + MoM (V1/V2/V3)</h2>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
        <div style={{ border: "1px solid #ddd", borderRadius: 8, padding: 12 }}>
          <h3 style={{ marginTop: 0 }}>Live Meeting</h3>

          <div style={{ display: "flex", gap: 10, flexWrap: "wrap", alignItems: "center" }}>
            <label>
              Room:
              <input value={roomId} onChange={(e) => setRoomId(e.target.value)} style={{ marginLeft: 6 }} />
            </label>
            <label>
              Language:
              <select value={language} onChange={(e) => setLanguage(e.target.value)} style={{ marginLeft: 6 }}>
                <option value="auto">auto</option>
                <option value="en">en</option>
                <option value="hi">hi</option>
                <option value="te">te</option>
                <option value="ta">ta</option>
                <option value="kn">kn</option>
                <option value="ml">ml</option>
                <option value="mr">mr</option>
                <option value="bn">bn</option>
              </select>
            </label>
            <div style={{ fontSize: 12, opacity: 0.7 }}>Status: {status}</div>
          </div>

          <div style={{ display: "flex", gap: 10, marginTop: 10, flexWrap: "wrap" }}>
            <button onClick={start} disabled={status === "live"}>Start</button>
            <button onClick={stop} disabled={status !== "live"}>Stop</button>
            <button onClick={saveMeeting} disabled={!transcript}>Save</button>
            <button onClick={generateMoM} disabled={!transcript}>Generate MoM</button>
            <button onClick={exportTxt} disabled={!transcript}>Export .txt</button>
            <button onClick={exportMd} disabled={!transcript}>Export .md</button>
          </div>

          <div style={{ marginTop: 10, fontSize: 12, opacity: 0.75 }}>
            Detected language: <b>{meta?.language || "—"}</b>
          </div>

          <h4>Transcript (live)</h4>
          <textarea value={transcript} onChange={(e) => setTranscript(e.target.value)} style={{ width: "100%", height: 220 }} />
        </div>

        <MeetingList meetings={meetings} onSelect={openMeeting} />
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14, marginTop: 14 }}>
        <MoMView mom={mom} />
        <div style={{ border: "1px solid #ddd", borderRadius: 8, padding: 12 }}>
          <h3 style={{ marginTop: 0 }}>Selected Meeting</h3>
          {selectedMeeting ? (
            <pre style={{ whiteSpace: "pre-wrap" }}>{JSON.stringify(selectedMeeting, null, 2)}</pre>
          ) : (
            <div style={{ opacity: 0.7 }}>Select a meeting from the list.</div>
          )}
        </div>
      </div>

      <div style={{ marginTop: 14, fontSize: 12, opacity: 0.7 }}>
        Tip: Open the same UI in two browser tabs, use same Room ID, start in one tab — transcript updates broadcast to both (V3 collaboration).
      </div>
    </div>
  );
}
