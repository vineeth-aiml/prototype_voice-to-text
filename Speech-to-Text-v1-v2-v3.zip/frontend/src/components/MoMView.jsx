import React from "react";

export default function MoMView({ mom }) {
  if (!mom) return <div style={{ opacity: 0.7 }}>No MoM generated yet.</div>;
  return (
    <div style={{ border: "1px solid #ddd", borderRadius: 8, padding: 12 }}>
      <h3 style={{ marginTop: 0 }}>MoM</h3>
      <div style={{ fontSize: 12, opacity: 0.7 }}>
        Engine: {mom.engine} | Language: {mom.language || "auto"}
      </div>

      {mom.summary && (
        <>
          <h4>Summary</h4>
          {Array.isArray(mom.summary) ? (
            <ul>{mom.summary.map((s, i) => <li key={i}>{String(s)}</li>)}</ul>
          ) : (
            <div>{String(mom.summary)}</div>
          )}
        </>
      )}

      {mom.decisions && (
        <>
          <h4>Decisions</h4>
          <ul>{mom.decisions.map((d, i) => <li key={i}>{String(d)}</li>)}</ul>
        </>
      )}

      {mom.action_items && (
        <>
          <h4>Action Items</h4>
          <ul>
            {mom.action_items.map((a, i) => (
              <li key={i}>
                {typeof a === "string" ? a : `${a.task || ""} ${a.owner ? `(Owner: ${a.owner})` : ""} ${a.due_date ? `(Due: ${a.due_date})` : ""}`}
              </li>
            ))}
          </ul>
        </>
      )}

      {mom.risks && (
        <>
          <h4>Risks</h4>
          <ul>{mom.risks.map((r, i) => <li key={i}>{String(r)}</li>)}</ul>
        </>
      )}

      {mom.next_steps && (
        <>
          <h4>Next Steps</h4>
          <ul>{mom.next_steps.map((n, i) => <li key={i}>{String(n)}</li>)}</ul>
        </>
      )}

      {mom.raw && (
        <>
          <h4>Raw</h4>
          <pre style={{ whiteSpace: "pre-wrap" }}>{mom.raw}</pre>
        </>
      )}
    </div>
  );
}
