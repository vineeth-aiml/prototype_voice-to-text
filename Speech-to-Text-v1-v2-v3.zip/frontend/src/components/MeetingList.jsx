import React from "react";

export default function MeetingList({ meetings, onSelect }) {
  return (
    <div style={{ border: "1px solid #ddd", borderRadius: 8, padding: 12 }}>
      <h3 style={{ marginTop: 0 }}>Meetings</h3>
      {meetings.length === 0 ? (
        <div>No meetings yet.</div>
      ) : (
        <ul style={{ paddingLeft: 18 }}>
          {meetings.map((m) => (
            <li key={m.id}>
              <button onClick={() => onSelect(m.id)} style={{ cursor: "pointer" }}>
                {m.id} {m.language ? `(${m.language})` : ""}
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
